BernAPlan 2.0 — Weekly Action Playbook — Fixed Standalone Version

OPEN THIS FILE:
  BernAPlan_2_FIXED_Standalone.html

On Windows: extract the ZIP (optional), then double-click the HTML file and open it in Microsoft Edge or Google Chrome. There are no separate CSS or JavaScript files to keep together. The previous version could appear as a plain white page when those extra files were missing.

On first launch, choose your own starter template and click "Create My Playbook." You'll see all seven days and five default time rows. Click a task to see instructions, checklists and completion options.

This is a zero-cost, offline, browser prototype. It saves to the browser storage for the local file, so BACK UP YOUR WORK via the app's JSON export before clearing browser data or switching devices.

The original BernAPlan Windows beta v0.4.2 was not changed. Google/Outlook calendar syncing, Android launcher and native wallpaper integration are not included in this first prototype.

GitHub development branch:
https://github.com/davidhambern-ship-it/BernAPlan/tree/feature/weekly-command-center-v2/prototype
