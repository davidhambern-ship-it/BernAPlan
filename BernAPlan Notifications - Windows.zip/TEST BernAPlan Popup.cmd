@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%LOCALAPPDATA%\BernAPlan\Notifier\BernAPlan_Notifier.ps1" -Test
