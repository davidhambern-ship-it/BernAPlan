@echo off
setlocal
taskkill /F /IM powershell.exe /FI "WINDOWTITLE eq BernAPlan*" >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\BernAPlan Notifier.vbs" >nul 2>&1
rmdir /S /Q "%LOCALAPPDATA%\BernAPlan\Notifier" >nul 2>&1
echo BernAPlan notifications removed.
pause
