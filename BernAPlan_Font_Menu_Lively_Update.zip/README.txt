# BernAPlan Font Loading Fix — Lively beta

1. Back up your current planner via its JSON export.
2. Import this ZIP into Lively Wallpaper as a NEW wallpaper, rather than overwriting the active one.
3. Open Customize > Appearance. Built-in font styles change the text immediately.
4. For your own typefaces, use Import your font collection, select your TTF/OTF files together, then pick them in the heading or body dropdown.
5. An option marked Ready has its real font file loaded. If it says Import required, a named entry alone is not enough.

If Lively does not allow permanent font storage in this wallpaper context, fonts work for this session but must be imported again after restart. To avoid that, install your personal fonts into Windows and restart Lively, or use its file importer when needed. Legacy PFM and FON are unsupported. One test TTF, The 2K12, was rejected by Chromium font parsing; choose another font or obtain a working licensed copy.

Font files are not included in this ZIP. Your BernAPlan data is stored separately from the old wallpaper. Back up JSON before switching. This release does not install or alter BernANotifier. No paid services or external network requests.
