BernAPlan 2.0 — Guided Playbook Prototype
========================================

OPEN THIS FILE: BernAPlan_2_Guided_Playbook.html

This is a standalone offline prototype. It does not change the installed
BernAPlan Beta v0.4.2 and does not cost anything to run.

What changed:
- 5-step click-through starter wizard: purpose, goal, obstacle, schedule, review
- Goal-specific task calendars on a permanent Monday–Sunday grid
- Specific guidance for common tasks, with tailored objectives, steps,
  practical planning tips, sample outcomes and checklists
- "Your next small action" walks through checklist items
- Existing generic starter instructions can be upgraded without replacing
  custom notes or personally authored instructions
- The editor can suggest a task guide from local free content

IMPORTANT:
This file stores changes in your browser's local storage. Its save storage
may be separate from an earlier HTML file based on the browser and file
location. If you have valuable work in the older prototype, export a JSON
backup from Backups first; you can import it into this version.

When rebuilding an existing weekly plan with the wizard, export a backup
before agreeing to replace its tasks. The wizard will ask for confirmation.

No paid AI, no accounts, no live Google/Outlook connection, and no native
Windows wallpaper or Android launcher integration yet.

Notes on the guidance:
Common workflows have curated instructions; unfamiliar custom titles get
editable suggested starter guidance rather than pretending to generate
expert-specific AI content. The user can edit every step.
